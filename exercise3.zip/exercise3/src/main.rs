fn main() {
    let str: Vec<char> = vec!['a','b','c','d','e'];
    let add_str = item_adder(str);
    println!("new vec is : {:?}",add_str);
}

fn item_adder(items:Vec<char>) -> Vec<char>{
    items.iter().map(|x| (*x as u8 + 1) as char).collect()
}

#[test]

fn test(){
    let str: Vec<char> = vec!['a','b','c','d','e'];
    let add_str = item_adder(str);
    assert_eq!(add_str,['b','c','d','e','f']);
}