fn main() {
    println!("Hello, world!");
}


fn compareString(x: &str, y: &str) -> bool{
    let mut i = 0;
    loop{
        if x.chars().nth(i) == None{return false};
        if y.chars().nth(i) == None{return true};
        if x.chars().nth(i)>y.chars().nth(i){ return true; }
        if x.chars().nth(i)<y.chars().nth(i){ return false;}
        if x.chars().nth(i)==y.chars().nth(i){ i+=1; }
    }
}

#[test]

fn test1(){
    let s1 = "abc";
    let s2 = "aaa";
    assert_eq!(compareString(s1, s2),true);
}

#[test]

fn test2(){
    let s1 = "000";
    let s2 = "123";
    assert_eq!(compareString(s1, s2),false);
}