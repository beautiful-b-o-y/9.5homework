use std::default::Default;//可以创建泛型的默认值

struct Buffer<T>{
    nums:Vec<T>,
}

impl<T> Buffer<T>{
    fn new(numbers:Vec<T>) ->Self{
        Buffer { nums: numbers}
    }

    fn sum(&self) -> T 
    where
        //对T进行约束：
        //1.std::ops::Add<Output=T> 要求T实现加法，且加法结果为T类型
        //2.Default 要求T类型具有一个初始值，可以初始化
        //3.Clone 要求T类型允许clone操作
        T: std::ops::Add<Output=T>+Default+Clone,
    {
        //利用T::default()将res初始化
        let mut res=T::default();
        //iter()返回的是&T类型无法进行加法，我们可以通过cloned()将其转化为T类型
        for item in self.nums.iter().cloned(){
            res = res + item;
        }
        res
    }
}

fn main() {
    let vec1:Vec<i32> = (1..=10).collect();
    let vec2:Vec<f64> = vec![1.5,2.5,3.5];
    let buffer1 = Buffer::new(vec1);
    let buffer2 = Buffer::new(vec2);
    println!("sum of vec1:{}",buffer1.sum());
    println!("sum of vec1:{}",buffer2.sum());
}

#[test]
fn test1(){
    let myvec:Vec<i32> = (1..=10).collect();
    let buffer = Buffer::new(myvec.clone());
    let sum:i32 = myvec.iter().cloned().sum();
    assert_eq!(sum,buffer.sum());
}

#[test]
fn test2(){
    let myvec:Vec<f64> = vec![1.5,2.5,3.5];
    let buffer = Buffer::new(myvec.clone());
    let sum:f64 = myvec.iter().cloned().sum();
    assert_eq!(sum,buffer.sum());
}


    

